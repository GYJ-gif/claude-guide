﻿#Requires -Version 5.1
# 只读预检：检查脚本语法、config.psd1 配置、Chrome 与纯净目录、系统代理、时区及桌面快捷方式。
# 不会修改时区、不会启动 Chrome、不会改系统代理。
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$fail = 0
function Check([string]$Name, [scriptblock]$Body) {
    try {
        $result = & $Body
        Write-Host ("OK   " + $Name + ': ' + $result) -ForegroundColor Green
    } catch {
        $script:fail++
        Write-Host ("FAIL " + $Name + ': ' + $_.Exception.Message) -ForegroundColor Red
    }
}

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
foreach ($f in @('Init-ChromeClean.ps1', 'Start-Claude.ps1', 'Restore-ChinaTime.ps1', 'Install-Shortcuts.ps1', 'Preflight.ps1')) {
    Check "语法检查 $f" {
        $path = Join-Path $here $f
        if (-not (Test-Path -LiteralPath $path)) { throw "缺少文件 $path" }
        $errs = $null; $tokens = $null
        $null = [System.Management.Automation.Language.Parser]::ParseFile($path, [ref]$tokens, [ref]$errs)
        if ($errs -and $errs.Count) { throw ($errs | ForEach-Object { $_.ToString() } | Out-String) }
        'AST OK'
    }
}

$cfgPath = Join-Path $here 'config.psd1'
$cfg = $null
Check '读取 config.psd1' {
    if (-not (Test-Path -LiteralPath $cfgPath)) { throw "缺少 $cfgPath" }
    $script:cfg = Import-PowerShellDataFile -Path $cfgPath
    "ExpectedExitIp=$($script:cfg.ExpectedExitIp), TargetTzId=$($script:cfg.TargetTzId)"
}

Check '家宽 IP 已填写' {
    if (-not $cfg -or [string]::IsNullOrWhiteSpace($cfg.ExpectedExitIp) -or $cfg.ExpectedExitIp -match '<|请填入|xxx') {
        throw '请在 config.psd1 中将 ExpectedExitIp 替换为你的真实静态家宽 IP'
    }
    $cfg.ExpectedExitIp
}

Check '目标时区有效' {
    [System.TimeZoneInfo]::FindSystemTimeZoneById([string]$cfg.TargetTzId).DisplayName
}

Check '恢复时区有效' {
    $homeTz = if ($cfg.HomeTzId) { [string]$cfg.HomeTzId } else { 'China Standard Time' }
    [System.TimeZoneInfo]::FindSystemTimeZoneById($homeTz).DisplayName
}

Check 'Chrome 可执行文件' {
    $candidates = @($cfg.ChromeExe, 'C:\Program Files\Google\Chrome\Application\chrome.exe', 'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe', (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe'))
    $found = $candidates | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
    if (-not $found) { throw '未找到 chrome.exe' }
    $found
}

$UserDataName = if ($cfg -and $cfg.UserDataDirName) { [string]$cfg.UserDataDirName } else { 'ChromeClean-US' }
$UserDataDir  = Join-Path $env:LOCALAPPDATA $UserDataName
Check 'ChromeClean-US 已初始化' {
    $ls = Join-Path $UserDataDir 'Local State'
    $dp = Join-Path $UserDataDir 'Default\Preferences'
    if (-not (Test-Path -LiteralPath $ls) -or -not (Test-Path -LiteralPath $dp)) {
        throw "未初始化，请先运行 Init-ChromeClean.ps1 并关闭弹出的空白 Chrome（目录：$UserDataDir）"
    }
    $UserDataDir
}

Check 'Windows 系统代理状态' {
    $inet = Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings'
    if ($inet.ProxyEnable -ne 1 -or [string]::IsNullOrWhiteSpace($inet.ProxyServer)) {
        throw '系统代理未开启，请在 Clash Verge / Mihomo Party 中开启「系统代理」'
    }
    $inet.ProxyServer
}

$Desktop = [Environment]::GetFolderPath('Desktop')
Check '桌面快捷方式「打开 Claude.lnk」' {
    $p = Join-Path $Desktop '打开 Claude.lnk'
    if (-not (Test-Path -LiteralPath $p)) { throw '尚未创建，请运行 Install-Shortcuts.ps1' }
    $s = (New-Object -ComObject WScript.Shell).CreateShortcut($p)
    $s.Arguments
}

Check '桌面快捷方式「恢复北京时间.lnk」' {
    $p = Join-Path $Desktop '恢复北京时间.lnk'
    if (-not (Test-Path -LiteralPath $p)) { throw '尚未创建，请运行 Install-Shortcuts.ps1' }
    $s = (New-Object -ComObject WScript.Shell).CreateShortcut($p)
    $s.Arguments
}

Write-Host ''
if ($fail -eq 0) {
    Write-Host 'PREFLIGHT PASSED（全部预检通过）' -ForegroundColor Green
    exit 0
} else {
    Write-Host "PREFLIGHT FAILED（共 $fail 项未通过，请按上方提示处理）" -ForegroundColor Red
    exit 1
}
