﻿@{
    # ==================== 每人只需修改下面两项 ====================
    # 1. 你自己购买的静态家宽出口 IP（例如 'xxx.xxx.xxx.xxx'）
    ExpectedExitIp  = 'xxx.xxx.xxx.xxx'

    # 2. 与你家宽所在城市匹配的 Windows 时区 ID：
    #    - 洛杉矶 / 西雅图 / 旧金山（美西）: 'Pacific Standard Time'
    #    - 丹佛 / 凤凰城（山地）           : 'Mountain Standard Time'
    #    - 芝加哥 / 达拉斯 / 休斯顿（美中）: 'Central Standard Time'
    #    - 纽约 / 弗吉尼亚 / 迈阿密（美东）: 'Eastern Standard Time'
    #    （其他地区可在终端运行 tzutil /l 查询）
    TargetTzId      = 'Pacific Standard Time'
    # ==============================================================

    # 以下一般无需修改
    HomeTzId        = 'China Standard Time'
    ClaudeUrl       = 'https://claude.ai'
    UserDataDirName = 'ChromeClean-US'
    # 留空则自动查找标准 Chrome 安装路径；若自定义安装位置可填写 chrome.exe 完整路径
    ChromeExe       = ''
}
