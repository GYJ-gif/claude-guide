﻿#Requires -Version 5.1
# 首次初始化独立的 Chrome Clean (US) 浏览器配置目录。
# 运行后会弹出一个全新的英文 Chrome 窗口，确认打开后直接关闭窗口即可完成初始化。
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$cfgPath = Join-Path $here 'config.psd1'
if (-not (Test-Path -LiteralPath $cfgPath)) { throw "缺少配置文件：$cfgPath" }
$cfg = Import-PowerShellDataFile -Path $cfgPath

function Resolve-ChromeExe([string]$Configured) {
    if ($Configured -and (Test-Path -LiteralPath $Configured)) { return $Configured }
    $candidates = @(
        'C:\Program Files\Google\Chrome\Application\chrome.exe',
        'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',
        (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
    )
    foreach ($c in $candidates) {
        if ($c -and (Test-Path -LiteralPath $c)) { return $c }
    }
    throw '未找到 Google Chrome，请先安装 Chrome 或在 config.psd1 中指定 ChromeExe 路径。'
}

$ChromeExe = Resolve-ChromeExe $cfg.ChromeExe
$WorkingDir = Split-Path -Parent $ChromeExe
$UserDataDir = Join-Path $env:LOCALAPPDATA $cfg.UserDataDirName

if (-not (Test-Path -LiteralPath $UserDataDir)) {
    New-Item -ItemType Directory -Path $UserDataDir -Force | Out-Null
}

Write-Host "将使用以下独立目录初始化 Chrome Clean (US)：" -ForegroundColor Cyan
Write-Host "  $UserDataDir" -ForegroundColor White
Write-Host "Chrome 打开后，请确认界面为英文，不要登录国内账号或开启同步，然后关闭该窗口即可。" -ForegroundColor Yellow

$chromeArgs = @(
    "--user-data-dir=$UserDataDir",
    '--lang=en-US',
    '--accept-lang=en-US,en',
    '--no-first-run',
    'about:blank'
)
Start-Process -FilePath $ChromeExe -WorkingDirectory $WorkingDir -ArgumentList $chromeArgs | Out-Null
Write-Host '已启动空白 Chrome Clean (US) 进行初始化。关闭窗口后再运行 Install-Shortcuts.ps1。' -ForegroundColor Green
Start-Sleep -Seconds 3
