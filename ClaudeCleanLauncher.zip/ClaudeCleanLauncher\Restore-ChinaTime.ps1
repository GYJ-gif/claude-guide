﻿#Requires -Version 5.1
# 将系统时区固定恢复为 China Standard Time（北京时间）。
# 不依赖任何临时状态文件，可放心多次点击「打开 Claude」后再点此脚本恢复。
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$cfgPath = Join-Path $here 'config.psd1'
$HomeTzId = 'China Standard Time'
if (Test-Path -LiteralPath $cfgPath) {
    try {
        $cfg = Import-PowerShellDataFile -Path $cfgPath
        if ($cfg.HomeTzId) { $HomeTzId = [string]$cfg.HomeTzId }
    } catch { }
}

function Show-Message([string]$Title, [string]$Message, [string]$Kind = 'Info') {
    Write-Host $Message
    try {
        Add-Type -AssemblyName PresentationFramework -ErrorAction Stop
        $icon = @{ Info = 'Information'; Error = 'Error'; Warn = 'Warning' }[$Kind]
        if (-not $icon) { $icon = 'Information' }
        [System.Windows.MessageBox]::Show($Message, $Title, 'OK', $icon) | Out-Null
    } catch {
        if ($Kind -eq 'Error') {
            Write-Host '按回车关闭...' -ForegroundColor Yellow
            try { [void][Console]::ReadLine() } catch { Start-Sleep -Seconds 12 }
        } else {
            Start-Sleep -Seconds 2
        }
    }
}

function Test-IsAdmin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-CurrentTzId {
    $id = (& tzutil /g 2>$null | Select-Object -First 1)
    if (-not $id) { $id = (Get-TimeZone).Id }
    return [string]$id.Trim()
}

$target = $HomeTzId
$current = Get-CurrentTzId
if ($current -eq $target) {
    Show-Message '恢复北京时间' "当前系统时区已是「$current」，无需更改。" 'Info'
    exit 0
}

Write-Host "将把系统时区从「$current」恢复为「$target」。" -ForegroundColor Yellow
try {
    if (Test-IsAdmin) {
        Set-TimeZone -Id $target
    } else {
        $cmd = "Set-TimeZone -Id '$target'; if ((Get-TimeZone).Id -ne '$target') { exit 1 }"
        $p = Start-Process -FilePath 'powershell.exe' -Verb RunAs -Wait -PassThru -WindowStyle Hidden -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', $cmd)
        if ($null -eq $p) { throw '未能发起时区恢复（可能未通过 UAC）。' }
        if ($p.ExitCode -ne 0) { throw "时区恢复失败或已取消 UAC（退出码 $($p.ExitCode)）。" }
    }
    Start-Sleep -Milliseconds 400
    $now = Get-CurrentTzId
    if ($now -ne $target) { throw "时区恢复后校验失败，当前为「$now」，期望「$target」。" }
    Show-Message '恢复北京时间' "系统时区已恢复为「$now」。" 'Info'
    exit 0
} catch {
    Show-Message '恢复北京时间失败' $_.Exception.Message 'Error'
    exit 1
}
