﻿#Requires -Version 5.1
# 打开 Claude（通用版）：
#   1. 读取同目录 config.psd1 中的家宽 IP 与目标时区
#   2. 校验独立的 Chrome Clean (US) 配置目录是否完整
#   3. 校验系统代理及 ipinfo.io 出口 IP 是否严格等于预期家宽 IP（不符则立即熔断，绝不打开网页）
#   4. 按需切换 Windows 系统时区至目标美国时区（用完请点桌面「恢复北京时间」）
#   5. 启动独立的 Chrome Clean (US) 打开 https://claude.ai
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
try { $PSDefaultParameterValues['*:Encoding'] = 'utf8' } catch { }

function Show-Error([string]$Message) {
    Write-Host ''
    Write-Host $Message -ForegroundColor Red
    try {
        Add-Type -AssemblyName PresentationFramework -ErrorAction Stop
        [System.Windows.MessageBox]::Show($Message, '打开 Claude 失败', 'OK', 'Error') | Out-Null
    } catch {
        try {
            Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
            [System.Windows.Forms.MessageBox]::Show($Message, '打开 Claude 失败') | Out-Null
        } catch {
            Write-Host '按回车关闭...' -ForegroundColor Yellow
            try { [void][Console]::ReadLine() } catch { Start-Sleep -Seconds 15 }
        }
    }
    exit 1
}

function Resolve-ChromeExe([string]$Configured) {
    if ($Configured -and (Test-Path -LiteralPath $Configured)) { return $Configured }
    $candidates = @(
        'C:\Program Files\Google\Chrome\Application\chrome.exe',
        'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',
        (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
    )
    foreach ($c in $candidates) {
        if ($c -and (Test-Path -LiteralPath $c)) { return $c }
    }
    return $null
}

function Test-IsAdmin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-CurrentTzId {
    $id = (& tzutil /g 2>$null | Select-Object -First 1)
    if (-not $id) { $id = (Get-TimeZone).Id }
    return [string]$id.Trim()
}

function Set-TimeZoneElevated([string]$Id) {
    if ((Get-CurrentTzId) -eq $Id) { return }
    if (Test-IsAdmin) {
        Set-TimeZone -Id $Id
    } else {
        $cmd = "Set-TimeZone -Id '$Id'; if ((Get-TimeZone).Id -ne '$Id') { exit 1 }"
        $p = Start-Process -FilePath 'powershell.exe' -Verb RunAs -Wait -PassThru -WindowStyle Hidden -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', $cmd)
        if ($null -eq $p) { throw '未能发起时区更改（可能未通过 UAC）。' }
        if ($p.ExitCode -ne 0) { throw "时区更改失败或已取消 UAC（退出码 $($p.ExitCode)）。" }
    }
    Start-Sleep -Milliseconds 400
    $now = Get-CurrentTzId
    if ($now -ne $Id) { throw "时区更改后校验失败，当前为「$now」，期望「$Id」。" }
}

# --- 读取配置 ---
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$cfgPath = Join-Path $here 'config.psd1'
if (-not (Test-Path -LiteralPath $cfgPath)) {
    Show-Error "缺少配置文件：`n$cfgPath`n未启动浏览器。"
}
$cfg = Import-PowerShellDataFile -Path $cfgPath

$ExpectedExitIp = [string]$cfg.ExpectedExitIp
$TargetTzId     = [string]$cfg.TargetTzId
$ClaudeUrl      = if ($cfg.ClaudeUrl) { [string]$cfg.ClaudeUrl } else { 'https://claude.ai' }
$UserDataName   = if ($cfg.UserDataDirName) { [string]$cfg.UserDataDirName } else { 'ChromeClean-US' }
$UserDataDir    = Join-Path $env:LOCALAPPDATA $UserDataName
$ChromeExe      = Resolve-ChromeExe ([string]$cfg.ChromeExe)

if ([string]::IsNullOrWhiteSpace($ExpectedExitIp) -or $ExpectedExitIp -match '<|请填入|xxx') {
    Show-Error "请先编辑配置文件填写你的家宽 IP：`n$cfgPath`n（将 ExpectedExitIp 改为你的静态家宽 IP）"
}
try {
    [void][System.TimeZoneInfo]::FindSystemTimeZoneById($TargetTzId)
} catch {
    Show-Error "config.psd1 中的 TargetTzId 无效：「$TargetTzId」`n请使用 tzutil /l 查看合法的 Windows 时区 ID。"
}

# --- 前置检查：Chrome 与纯净目录，失败则绝不启动浏览器 ---
if (-not $ChromeExe) {
    Show-Error "未找到 Google Chrome。`n请先安装 Chrome，或在 config.psd1 中指定 ChromeExe 路径。"
}
$WorkingDir = Split-Path -Parent $ChromeExe

if (-not (Test-Path -LiteralPath $UserDataDir)) {
    Show-Error "未找到 Chrome Clean (US) 用户数据目录：`n$UserDataDir`n请先运行 Init-ChromeClean.ps1 初始化空白配置，未启动浏览器。"
}
$defaultPrefs = Join-Path $UserDataDir 'Default\Preferences'
$localState = Join-Path $UserDataDir 'Local State'
if (-not (Test-Path -LiteralPath $localState) -or -not (Test-Path -LiteralPath $defaultPrefs)) {
    Show-Error "Chrome Clean (US) 配置不完整（缺少 Local State 或 Default\Preferences）。`n请先运行 Init-ChromeClean.ps1 打开空白窗口后再关闭，完成初始化。"
}

# --- 系统代理提示检查（只读，不修改系统代理） ---
$inet = Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -ErrorAction SilentlyContinue
if (-not $inet -or $inet.ProxyEnable -ne 1 -or [string]::IsNullOrWhiteSpace($inet.ProxyServer)) {
    Write-Host '提示：当前 Windows 系统代理未开启。如果你使用本地代理客户端（Clash Verge / Mihomo Party），请先开启「系统代理」与「规则模式」。' -ForegroundColor Yellow
} else {
    Write-Host "检测到系统代理：$($inet.ProxyServer)" -ForegroundColor Cyan
}

# --- 代理出口强校验（只读，不改系统代理） ---
Write-Host '正在检查代理出口 IP...' -ForegroundColor Cyan
$exitIp = $null
$exitInfo = $null
try {
    $prevProto = [Net.ServicePointManager]::SecurityProtocol
    try { [Net.ServicePointManager]::SecurityProtocol = $prevProto -bor [Net.SecurityProtocolType]::Tls12 } catch { }
    $exitInfo = Invoke-RestMethod -Uri 'https://ipinfo.io/json' -TimeoutSec 15
    if ($exitInfo -and $exitInfo.ip) { $exitIp = [string]$exitInfo.ip.Trim() }
} catch {
    Show-Error ("无法检查代理出口（未改时区，未打开网页）：`n" + $_.Exception.Message + "`n请确认代理客户端已启动、已开系统代理并处于规则模式后再试。")
}
if ([string]::IsNullOrWhiteSpace($exitIp)) {
    Show-Error '无法检查代理出口：未得到 IP。未改时区，未打开网页。'
}
if ($exitIp -ne $ExpectedExitIp.Trim()) {
    $loc = if ($exitInfo) { "$($exitInfo.city), $($exitInfo.region), $($exitInfo.country) ($($exitInfo.org))" } else { '未知' }
    Show-Error "代理出口不符合预期！`n当前出口：$exitIp（$loc）`n期望出口：$ExpectedExitIp`n请检查客户端是否开启「系统代理」+「规则模式」且 JS 覆写已生效。`n未改时区，未打开网页。"
}
Write-Host "出口 IP 检查通过：$exitIp（$($exitInfo.city), $($exitInfo.region), $($exitInfo.timezone)）" -ForegroundColor Green

# --- 时区切换（需要时走 UAC；已是目标时区则跳过） ---
$currentTz = Get-CurrentTzId
Write-Host "当前系统时区：$currentTz" -ForegroundColor Cyan
if ($currentTz -ne $TargetTzId) {
    Write-Host "将把系统时区改为 $TargetTzId（全局设置，用完请点桌面「恢复北京时间」）。" -ForegroundColor Yellow
    try {
        Set-TimeZoneElevated -Id $TargetTzId
        Write-Host "时区已切换为 $(Get-CurrentTzId)。" -ForegroundColor Green
    } catch {
        Show-Error ("切换时区失败，未打开 Claude：`n" + $_.Exception.Message)
    }
} else {
    Write-Host '系统时区已是目标时区，无需更改。' -ForegroundColor Green
}

# --- 启动隔离的 Chrome Clean (US) ---
$chromeArgs = @(
    "--user-data-dir=$UserDataDir",
    '--lang=en-US',
    '--accept-lang=en-US,en',
    '--no-first-run',
    $ClaudeUrl
)
try {
    Start-Process -FilePath $ChromeExe -WorkingDirectory $WorkingDir -ArgumentList $chromeArgs | Out-Null
} catch {
    Show-Error ("时区可能已切换，但未能启动 Chrome：`n" + $_.Exception.Message + "`n请手动点「恢复北京时间」，或再试一次。")
}
Write-Host "已用 Chrome Clean (US) 打开 $ClaudeUrl" -ForegroundColor Green
Write-Host '用完后请点桌面上的「恢复北京时间」。' -ForegroundColor Yellow
Start-Sleep -Seconds 2
