﻿#Requires -Version 5.1
# 自动将本套件部署到 %LOCALAPPDATA%\ClaudeCleanLauncher 并在桌面创建快捷方式。
# 不改时区，不启动 Chrome。
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$SourceDir  = Split-Path -Parent $MyInvocation.MyCommand.Path
$TargetDir  = Join-Path $env:LOCALAPPDATA 'ClaudeCleanLauncher'
$Desktop    = [Environment]::GetFolderPath('Desktop')

$requiredFiles = @(
    'config.psd1',
    'Init-ChromeClean.ps1',
    'Start-Claude.ps1',
    'Restore-ChinaTime.ps1',
    'Install-Shortcuts.ps1',
    'Preflight.ps1'
)

foreach ($f in $requiredFiles) {
    $p = Join-Path $SourceDir $f
    if (-not (Test-Path -LiteralPath $p)) { throw "缺少必需文件：$p" }
}

# 若当前是从解压目录运行，则自动复制到 %LOCALAPPDATA%\ClaudeCleanLauncher
if ([System.IO.Path]::GetFullPath($SourceDir).TrimEnd('\') -ine [System.IO.Path]::GetFullPath($TargetDir).TrimEnd('\')) {
    if (-not (Test-Path -LiteralPath $TargetDir)) {
        New-Item -ItemType Directory -Path $TargetDir -Force | Out-Null
    }
    foreach ($f in $requiredFiles) {
        Copy-Item -LiteralPath (Join-Path $SourceDir $f) -Destination (Join-Path $TargetDir $f) -Force
    }
    Write-Host "已将脚本部署到：$TargetDir" -ForegroundColor Cyan
}

$cfg = Import-PowerShellDataFile -Path (Join-Path $TargetDir 'config.psd1')

function Resolve-ChromeExe([string]$Configured) {
    if ($Configured -and (Test-Path -LiteralPath $Configured)) { return $Configured }
    $candidates = @(
        'C:\Program Files\Google\Chrome\Application\chrome.exe',
        'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',
        (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
    )
    foreach ($c in $candidates) {
        if ($c -and (Test-Path -LiteralPath $c)) { return $c }
    }
    throw '未找到 Google Chrome，请先安装 Chrome 或在 config.psd1 中指定 ChromeExe 路径。'
}

$ChromeExe    = Resolve-ChromeExe ([string]$cfg.ChromeExe)
$ChromeWork   = Split-Path -Parent $ChromeExe
$UserDataName = if ($cfg.UserDataDirName) { [string]$cfg.UserDataDirName } else { 'ChromeClean-US' }
$UserDataDir  = Join-Path $env:LOCALAPPDATA $UserDataName
$StartPs1     = Join-Path $TargetDir 'Start-Claude.ps1'
$RestorePs1   = Join-Path $TargetDir 'Restore-ChinaTime.ps1'

$shell = New-Object -ComObject WScript.Shell

# 1. 打开 Claude.lnk
$claudeLnk = Join-Path $Desktop '打开 Claude.lnk'
$s1 = $shell.CreateShortcut($claudeLnk)
$s1.TargetPath       = 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
$s1.Arguments        = "-NoProfile -ExecutionPolicy Bypass -File `"$StartPs1`""
$s1.WorkingDirectory = $TargetDir
$s1.WindowStyle      = 1
$s1.Description      = '先校验家宽出口 IP 并切换美国时区，再用 Chrome Clean (US) 打开 Claude'
$s1.IconLocation     = "$ChromeExe,0"
$s1.Save()

# 2. 恢复北京时间.lnk
$restoreLnk = Join-Path $Desktop '恢复北京时间.lnk'
$s2 = $shell.CreateShortcut($restoreLnk)
$s2.TargetPath       = 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
$s2.Arguments        = "-NoProfile -ExecutionPolicy Bypass -File `"$RestorePs1`""
$s2.WorkingDirectory = $TargetDir
$s2.WindowStyle      = 1
$s2.Description      = '将系统时区固定恢复为北京时间（China Standard Time）'
$s2.IconLocation     = 'C:\Windows\System32\timedate.cpl,0'
$s2.Save()

# 3. Chrome Clean (US).lnk（备用纯净浏览器入口，不改时区）
$chromeLnk = Join-Path $Desktop 'Chrome Clean (US).lnk'
$s3 = $shell.CreateShortcut($chromeLnk)
$s3.TargetPath       = $ChromeExe
$s3.Arguments        = "--user-data-dir=`"$UserDataDir`" --lang=en-US --accept-lang=en-US,en --no-first-run"
$s3.WorkingDirectory = $ChromeWork
$s3.WindowStyle      = 1
$s3.Description      = '独立的英文纯净 Chrome 环境（仅用于美区服务与环境体检）'
$s3.IconLocation     = "$ChromeExe,0"
$s3.Save()

Write-Host ''
Write-Host '桌面快捷方式已创建：' -ForegroundColor Green
Write-Host "  1. $claudeLnk"
Write-Host "  2. $restoreLnk"
Write-Host "  3. $chromeLnk"
Write-Host "脚本安装目录：$TargetDir" -ForegroundColor Cyan
Write-Host '提示：若以后修改了 IP 或时区，请修改上述安装目录里的 config.psd1（或改完后重新运行本脚本）。' -ForegroundColor Yellow
